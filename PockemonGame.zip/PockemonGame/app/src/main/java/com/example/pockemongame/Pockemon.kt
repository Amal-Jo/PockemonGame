package com.example.pockemongame

import android.location.Location

class Pockemon {
    var name: String? = null
    var description: String? = null
    var image: Int? = null
    var power: Double? = null
    var location:Location?=null
    var IsCatch: Boolean? = false

    constructor(image: Int, name: String, description: String, power: Double, lat: Double, lon: Double) {

        this.image=image
        this.name=name
        this.description=description
        this.power=power
        this.location=Location(name)
        this.location!!.latitude=lat
        this.location!!.longitude=lon
        this.IsCatch=false
    }
}